rpmonbart <- function (x.train, y.train, x.test = matrix(0, 0, 0), sigest = NA, 
                       sigdf = 3, sigquant = 0.9, k = 2, power = 0.8, base = 0.25, 
                       sigmaf = NA, lambda = NA, fmean = mean(y.train), ntree = 200L, 
                       ndpost = 1000L, nskip = 100L, mgsize = 50L, nkeeptrain = ndpost, 
                       nkeeptest = ndpost, nkeeptestmean = ndpost, nkeeptreedraws = ndpost, 
                       printevery = 10, seed = 99L, mc.cores = 1L) 
{
  cat("***** in rpmonbart\n")
  p = ncol(x.train)
  n = nrow(x.train)
  nu = sigdf
  if (is.na(lambda)) {
    if (is.na(sigest)) {
      if (p < n) {
        df = data.frame(x.train, y.train)
        lmf = lm(y.train ~ ., df)
        sigest = summary(lmf)$sigma
      }
      else {
        sigest = sd(y.train)
      }
    }
    qchi = qchisq(1 - sigquant, nu)
    lambda = (sigest * sigest * qchi)/nu
  }
  if (is.na(sigmaf)) {
    tau = (max(y.train) - min(y.train))/(2 * k * sqrt(ntree))
  }
  else {
    tau = sigmaf/sqrt(ntree)
  }
  RNGkind("L'Ecuyer-CMRG")
  set.seed(seed)
  mc.ndpost <- (ndpost%/%mc.cores)
  cat("ndpost: ", ndpost, "\n")
  cat("mc.ndpost: ", mc.ndpost, "\n")
  mc.nkeeptrain = (nkeeptrain%/%mc.cores)
  mc.nkeeptest = (nkeeptest%/%mc.cores)
  mc.nkeeptestmean = (nkeeptestmean%/%mc.cores)
  mc.nkeeptreedraws = (nkeeptreedraws%/%mc.cores)
  cat("mc.cores: ", mc.cores, "\n")
  cl <- makeCluster(mc.cores)
  post.list <- clusterCall(cl, fun = monbart, x.train = x.train, 
                           y.train = y.train, x.test = x.test, sigest = NA, sigdf = nu, 
                           sigquant = sigquant, k = 2, power = power, base = base, 
                           sigmaf = tau * sqrt(ntree), lambda = lambda, fmean = fmean, 
                           ntree = ntree, ndpost = mc.ndpost, nskip = nskip, mgsize = mgsize, 
                           nkeeptrain = mc.nkeeptrain, nkeeptest = mc.nkeeptest, 
                           nkeeptestmean = mc.nkeeptestmean, nkeeptreedraws = 0, 
                           printevery = printevery)
  stopCluster(cl)
  cat("length of post.list: ", length(post.list), "\n")
  np = nrow(x.test)
  if (nkeeptrain) 
    yhat.train.ret = post.list[[1]]$yhat.train
  burnL = vector("list", mc.cores)
  burnL[[1]] = post.list[[1]]$sigma[1:nskip]
  sigma = c(post.list[[1]]$sigma[1:mc.ndpost + nskip])
  if (np) 
    yhat.test.ret = post.list[[1]]$yhat.test
  yhat.train.mean = post.list[[1]]$yhat.train.mean
  if (np) 
    yhat.test.mean = post.list[[1]]$yhat.test.mean
  if (mc.cores > 1) {
    for (i in 2:mc.cores) {
      if (nkeeptrain) 
        yhat.train.ret = rbind(yhat.train.ret, post.list[[i]]$yhat.train)
      if (np) 
        yhat.test.ret = rbind(yhat.test.ret, post.list[[i]]$yhat.test)
      burnL[[i]] = post.list[[i]]$sigma[1:nskip]
      sigma = c(sigma, post.list[[i]]$sigma[1:mc.ndpost + 
                                              nskip])
      yhat.train.mean = yhat.train.mean + post.list[[i]]$yhat.train.mean
      if (np) 
        yhat.test.mean = yhat.test.mean + post.list[[i]]$yhat.test.mean
    }
  }
  ret = list()
  if (nkeeptrain) 
    ret$yhat.train = yhat.train.ret
  ret$yhat.train.mean = yhat.train.mean/mc.cores
  if (np) {
    if (nkeeptest) 
      ret$yhat.test = yhat.test.ret
    if (nkeeptestmean) 
      ret$yhat.test.mean = yhat.test.mean/mc.cores
  }
  ret$sigma = sigma
  ret$burnlist = burnL
  
  ret$x <- x.train
  ret$y <- y.train
  
  #ret$prob.test<- pnorm(ret$yhat.test)
  #ret$prob.test.mean.1 <- colMeans(ret$prob.test)
  
  #ret$prob.test.mean.2 <- pnorm(ret$yhat.test.mean)
  
  #ret$prob.train <- pnorm(ret$yhat.train)
  #ret$prob.train.mean.1 <- colMeans(ret$prob.train) # compute means from here 
  
  #ret$prob.train.mean.2 <- pnorm(ret$yhat.train.mean) # from already computed means
  return(ret)
}

