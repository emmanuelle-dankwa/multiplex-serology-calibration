pmonbart <- function (x.train, y.train, x.test = matrix(0, 0, 0), k = 2, 
                      power = 0.8, base = 0.25, binaryOffset = NULL, ntree = 200, 
                      ndpost = 1000, nskip = 100, mgsize = 50, nkeeptrain = ndpost, 
                      nkeeptest = ndpost, nkeeptestmean = ndpost, nkeeptreedraws = ndpost, 
                      printevery = 10) 
{
  nd = ndpost
  burn = nskip
  n = length(y.train)
  p = ncol(x.train)
  np = nrow(x.test)
  x = t(x.train)
  xp = t(x.test)
  if ((nkeeptrain != 0) & ((ndpost%%nkeeptrain) != 0)) {
    nkeeptrain = ndpost
    cat("*****nkeeptrain set to ndpost\n")
  }
  if ((nkeeptest != 0) & ((ndpost%%nkeeptest) != 0)) {
    nkeeptest = ndpost
    cat("*****nkeeptest set to ndpost\n")
  }
  if ((nkeeptestmean != 0) & ((ndpost%%nkeeptestmean) != 0)) {
    nkeeptestmean = ndpost
    cat("*****nkeeptestmean set to ndpost\n")
  }
  if ((nkeeptreedraws != 0) & ((ndpost%%nkeeptreedraws) != 
                               0)) {
    nkeeptreedraws = ndpost
    cat("*****nkeeptreedraws set to ndpost\n")
  }
  if (length(binaryOffset) == 0) {
    binaryOffset <- qnorm(mean(y.train))
  }
  tau <- 3/(k * sqrt(ntree))
  res = cpmonbart(x, y.train, xp, tau, base, power, binaryOffset, 
                  nd, burn, ntree, mgsize, nkeeptrain, nkeeptest, nkeeptestmean, 
                  nkeeptreedraws, printevery)
  res$yhat.train <- res$yhat.train + binaryOffset
  res$prob.train <- pnorm(res$yhat.train)
  res$prob.train.mean <- colMeans(res$prob.train)
  res$yhat.test <- res$yhat.test + binaryOffset
  res$prob.test <- pnorm(res$yhat.test)
 # res$prob.test.mean <- colMeans(res$prob.test)
  res$x <- x.train
  res$y <- y.train
  return(res)
}
